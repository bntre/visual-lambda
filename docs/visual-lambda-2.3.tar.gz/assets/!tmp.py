
print("http://127.0.0.1:8000/#workspace=", end="")

for i in range(270):
    #print("%-10d" % ((i+1)*10,), end="")
    print(f"{(i+1)*10:->10}", end="")
    #print(str((i+1)*10).zfill(10), end="")



